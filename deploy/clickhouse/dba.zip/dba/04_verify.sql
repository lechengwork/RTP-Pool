-- 新 Kafka consumer 啟動後執行；latest_time 應持續前進，event_rows 應等於 distinct_offsets。
SELECT
    count() AS event_rows,
    min(GR_EndTime) AS earliest_time,
    max(GR_EndTime) AS latest_time,
    countDistinct(tuple(kafka_topic, kafka_partition, kafka_offset)) AS distinct_offsets
FROM icrown.rtp_basic_pool_event_log
FINAL;

SELECT
    AGT_Agent1,
    GM_GameCode,
    GameServer_Version,
    bet,
    win
FROM icrown.rtp_basic_pool_stats
ORDER BY bet DESC
LIMIT 20;
