-- RTP基本池 MVP：Kafka source + 單一事件/telemetry 表 + 統計 View。

CREATE TABLE IF NOT EXISTS icrown.rtp_basic_pool_event_log_local
ON CLUSTER sg_cluster
(
    GR_SEQ UInt64 COMMENT '來源注單序號',
    AGT_Agent1 LowCardinality(String) COMMENT '總代 ID',
    GM_GameCode LowCardinality(String) COMMENT '老虎機 ID',
    GameServer_Version LowCardinality(String) COMMENT 'RTP 版本 ID',
    GR_EndTime DateTime64(9, 'Etc/GMT+4') COMMENT 'spin 結算時間',
    GR_Bets Decimal(22, 4) COMMENT '當轉總下注',
    GR_Win Decimal(22, 4) COMMENT '當轉總派彩',
    GR_BetType UInt8 COMMENT '0=一般、1=FeatureBuy、2=ExtraBet、3=SuperFeatureBuy',
    IsTestRng Bool COMMENT '測試 RNG 標記',

    r Nullable(Float64) COMMENT '目標 RTP；格式非法為 NULL',
    is_buy_type UInt8 COMMENT 'GR_BetType 為 1 或 3 時等於 1',
    metric Nullable(Float64) COMMENT '服務計算前的 Dl / Bl；尚未處理為 NULL',
    band Nullable(Float64) COMMENT '當轉動態帶寬；尚未處理為 NULL',
    triggered Nullable(UInt8) COMMENT '服務處理後 Phase 1 寫 0；尚未處理為 NULL',
    candidate_count Nullable(UInt16) COMMENT '觸發時 N；Phase 1 為 NULL',
    selected_candidate_win Nullable(Float64) COMMENT '觸發時選中派彩；Phase 1 為 NULL',
    processed_at Nullable(DateTime64(6, 'Etc/GMT+4')) COMMENT '服務完成本事件計算的時間',

    kafka_topic LowCardinality(String) COMMENT 'Kafka topic',
    kafka_partition UInt64 COMMENT 'Kafka partition',
    kafka_offset UInt64 COMMENT 'Kafka offset',
    updated_at DateTime64(6, 'Etc/GMT+4') COMMENT '事件版本時間'
)
ENGINE = ReplicatedReplacingMergeTree(
    '/clickhouse/tables/{shard}/icrown/rtp_basic_pool_event_log_local',
    '{replica}',
    updated_at
)
PARTITION BY toYYYYMMDD(GR_EndTime)
ORDER BY (kafka_topic, kafka_partition, kafka_offset);

CREATE TABLE IF NOT EXISTS icrown.rtp_basic_pool_event_log
ON CLUSTER sg_cluster
AS icrown.rtp_basic_pool_event_log_local
ENGINE = Distributed(
    'sg_cluster',
    'icrown',
    'rtp_basic_pool_event_log_local',
    cityHash64(kafka_topic, kafka_partition)
);

CREATE VIEW IF NOT EXISTS icrown.rtp_basic_pool_event_log_latest
ON CLUSTER sg_cluster
AS
SELECT
    argMax(GR_SEQ, updated_at) AS GR_SEQ,
    argMax(AGT_Agent1, updated_at) AS AGT_Agent1,
    argMax(GM_GameCode, updated_at) AS GM_GameCode,
    argMax(GameServer_Version, updated_at) AS GameServer_Version,
    argMax(GR_EndTime, updated_at) AS GR_EndTime,
    argMax(GR_Bets, updated_at) AS GR_Bets,
    argMax(GR_Win, updated_at) AS GR_Win,
    argMax(GR_BetType, updated_at) AS GR_BetType,
    argMax(IsTestRng, updated_at) AS IsTestRng,
    argMax(r, updated_at) AS r,
    argMax(is_buy_type, updated_at) AS is_buy_type,
    argMax(metric, updated_at) AS metric,
    argMax(band, updated_at) AS band,
    argMax(triggered, updated_at) AS triggered,
    argMax(candidate_count, updated_at) AS candidate_count,
    argMax(selected_candidate_win, updated_at) AS selected_candidate_win,
    argMax(processed_at, updated_at) AS processed_at,
    kafka_topic,
    kafka_partition,
    kafka_offset,
    max(updated_at) AS updated_at
FROM icrown.rtp_basic_pool_event_log
GROUP BY
    kafka_topic,
    kafka_partition,
    kafka_offset;

CREATE VIEW IF NOT EXISTS icrown.rtp_basic_pool_stats
ON CLUSTER sg_cluster
AS
SELECT
    AGT_Agent1,
    GM_GameCode,
    GameServer_Version,
    sum(CAST(GR_Bets AS Decimal(38, 12))) AS bet,
    sum(CAST(GR_Win AS Decimal(38, 12))) AS win
FROM icrown.rtp_basic_pool_event_log_latest
WHERE IsTestRng = 0
GROUP BY
    AGT_Agent1,
    GM_GameCode,
    GameServer_Version;

-- 完整 payload schema 與 SG 線上 icrown.ke_slotgame 逐欄一致。
CREATE TABLE IF NOT EXISTS icrown.rtp_basic_pool_kafka_source
ON CLUSTER sg_cluster
(
    GR_SEQ UInt64,
    GM_GameCode LowCardinality(String),
    AGT_Agent1 LowCardinality(String),
    AGT_Agent2 LowCardinality(String),
    AGT_Agent3 LowCardinality(String),
    PLY_GUID String,
    AGT_AccountID LowCardinality(String),
    PLY_AccountID String,
    GR_Currency LowCardinality(String),
    GR_Bets Decimal(22, 4),
    GR_GamebleBets Decimal(22, 4),
    GR_Win Decimal(22, 4),
    GR_ValidBets Decimal(22, 4),
    GR_NetWin Decimal(22, 4),
    GR_Jackpot Decimal(22, 4),
    GR_JackpotType UInt8,
    GR_JackpotContribute Decimal(22, 4),
    GR_Record String,
    GR_FlagFreeGame Bool,
    GR_FlagGamble Bool,
    GR_FlagInterrupt Bool,
    GR_StartTime DateTime64(9, 'Etc/GMT+4'),
    GR_EndTime DateTime64(9, 'Etc/GMT+4'),
    GR_IPAddress String,
    GameServer_Version LowCardinality(String),
    GameServer_Name LowCardinality(String),
    GR_BeforeBalance Decimal(22, 4),
    GR_AfterBalance Decimal(22, 4),
    GR_CreateDateTime DateTime64(9, 'Etc/GMT+4'),
    GR_ClientType UInt8,
    GR_BetType UInt8,
    GR_RecordCompress String,
    Multiplier Decimal(10, 4),
    GitVersion LowCardinality(String),
    GitCommitHash FixedString(40),
    MathBet Decimal(18, 4),
    MathTotalBet Decimal(22, 4),
    IsTestRng Bool,
    Extend Array(Int64),
    UsedRng Array(Int64)
)
ENGINE = Kafka
SETTINGS
    kafka_broker_list = '172.31.15.82:9092,172.31.12.252:9092,172.31.5.49:9092',
    kafka_topic_list = 'LCGAME.slotGame.winloseV1',
    kafka_group_name = 'rtp_basic_pool_sg_v1',
    kafka_format = 'JSONEachRow',
    date_time_input_format = 'best_effort',
    kafka_num_consumers = 8;

CREATE MATERIALIZED VIEW IF NOT EXISTS icrown.rtp_basic_pool_kafka_to_event_log
ON CLUSTER sg_cluster
TO icrown.rtp_basic_pool_event_log_local
AS
SELECT
    GR_SEQ,
    AGT_Agent1,
    GM_GameCode,
    GameServer_Version,
    GR_EndTime,
    GR_Bets,
    GR_Win,
    GR_BetType,
    IsTestRng,
    if(
        match(GameServer_Version, '^0[0-9]{3}$'),
        toFloat64OrNull(GameServer_Version) / 1000,
        NULL
    ) AS r,
    toUInt8(GR_BetType IN (1, 3)) AS is_buy_type,
    CAST(NULL AS Nullable(Float64)) AS metric,
    CAST(NULL AS Nullable(Float64)) AS band,
    CAST(NULL AS Nullable(UInt8)) AS triggered,
    CAST(NULL AS Nullable(UInt16)) AS candidate_count,
    CAST(NULL AS Nullable(Float64)) AS selected_candidate_win,
    CAST(NULL AS Nullable(DateTime64(6, 'Etc/GMT+4'))) AS processed_at,
    _topic AS kafka_topic,
    _partition AS kafka_partition,
    _offset AS kafka_offset,
    now64(6, 'Etc/GMT+4') AS updated_at
FROM icrown.rtp_basic_pool_kafka_source;
